class Controller:

    def __init__(self):
        self.players = []
        self.supplies = []

    def add_player(self, *players):
        players = list(players)
        for player in players:
            if player in self.players:
                players.remove(player)
            else:
                self.players.append(player)
        return f"Successfully added: {', '.join(p.name for p in players)}"

    def add_supply(self, *args):
        for supply in args:
            self.supplies.append(supply)

    def sustain(self, player_name, sustenance_type):
        player = [p for p in self.players if p.name == player_name][0]
        if not player.need_sustenance:
            return f"{player_name} have enough stamina."

        if sustenance_type in ("Food", "Drink"):
            supply = None
            for i in range(len(self.supplies) - 1, -1, -1):
                if self.supplies[i].__class__.__name__ == sustenance_type:
                    supply = self.supplies[i]
                    self.supplies.pop(i)
                    break
            else:
                if sustenance_type == "Food":
                    raise Exception("There are no food supplies left!")
                else:
                    raise Exception("There are no drink supplies left!")

            if player.stamina + supply.energy > 100:
                player.stamina = 100
            else:
                player.stamina += supply.energy

            return f"{player_name} sustained successfully with {supply.name}."

    def duel(self, fp_name, sp_name):
        player1 = [p for p in self.players if p.name == fp_name][0]
        player2 = [p for p in self.players if p.name == sp_name][0]

        if not player1.stamina and not player2.stamina:
            return f"Player {fp_name} does not have enough stamina" \
                   f"Player {sp_name} does not have enough stamina"
        elif not player1.stamina:
            return f"Player {fp_name} does not have enough stamina"
        elif not player2.stamina:
            return f"Player {sp_name} does not have enough stamina"

        if player2.stamina < player1.stamina:
            player1, player2 = player2, player1

        player2.stamina -= player1.stamina / 2

        if player1.stamina - player2.stamina / 2 <= 0:
            player1.stamina = 0
            return f"Winner: {player2.name}"
        else:
            player1.stamina -= player2.stamina / 2

        if player1.stamina > player2.stamina:
            return f"Winner: {player1.name}"
        else:
            return f"Winner: {player2.name}"

    def next_day(self):
        for p in self.players:
            if p.stamina - p.age * 2 <= 0:
                p.stamina = 0
            else:
                p.stamina -= p.age * 2
        for p in self.players:
            self.sustain(p.name, "Food")
            self.sustain(p.name, "Drink")

    def __str__(self):
        result = []
        for p in self.players:
            result.append(str(p))
        for s in self.supplies:
            result.append(s.details())

        return "\n".join(result)
